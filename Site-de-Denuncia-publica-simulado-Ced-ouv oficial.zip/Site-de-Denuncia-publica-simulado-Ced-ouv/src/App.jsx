import './App.css';
import RouterComp from './components/Router/Router';

function App() {
  return (
    <div className="App">
      <RouterComp />
    </div>
  );
}

export default App;