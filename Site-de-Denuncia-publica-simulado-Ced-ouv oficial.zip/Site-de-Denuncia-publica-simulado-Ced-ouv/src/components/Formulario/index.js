export { default as DenunciaForm } from "./DenunciaForm";
export { default as ReclamacaoForm } from "./ReclamacaoForm";
export { default as ElogioForm } from "./ElogioForm";
export { default as SugestaoForm } from "./SugestaoForm";
export { default as InformacaoForm } from "./InformacaoForm";